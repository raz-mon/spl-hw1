//
// Created by spl211 on 03/11/2020.
//

#include "../include/Graph.h"
#include <string>

using namespace std;

Graph::Graph():edges(){}

Graph::Graph(std::vector<std::vector<int>> matrix): edges(matrix){}

bool Graph::finish(){
    // Build connectivity components and check for solidarity among them.
}





